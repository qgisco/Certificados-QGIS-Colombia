Source: Bitstream Vera Sans test font from MapServer project (Feb. 2014)

Family name: QGIS Vera Sans

The family name prefix of Bitstream has been set to QGIS so as to never conflict
with any other installed font on user's system, when loaded into QFontDatabase.

DO NOT INSTALL THIS FONT ON YOUR SYSTEM.
It is intended to be loaded by Qt on-the-fly during tests.
